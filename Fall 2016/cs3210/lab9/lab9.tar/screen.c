/*
	screen.c
	by Ted Cowan
*/

#include <stdio.h>
#include "addr.h"

int screenStuff(void) {
	printf("I am screen.c\n");
	return 0;
}
