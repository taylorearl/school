/*
	db.c
	by Ted Cowan
*/

#include <stdio.h>
#include "addr.h"

int dbStuff(void) {
	printf("I am db.c\n");
	return 0;
}
