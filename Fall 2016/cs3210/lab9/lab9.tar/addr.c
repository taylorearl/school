/*
	addr.c
	by Ted Cowan
	for CS 3210
	Fall 2005
*/

#include <stdio.h>
#include "addr.h"

int main(int argc, char **argv) {
	printf("I am addr.c\n");
	dbStuff();
	screenStuff();
	return 0;
}
