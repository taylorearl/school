﻿namespace assignment4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grid00 = new System.Windows.Forms.Label();
            this.grid10 = new System.Windows.Forms.Label();
            this.grid20 = new System.Windows.Forms.Label();
            this.grid01 = new System.Windows.Forms.Label();
            this.grid11 = new System.Windows.Forms.Label();
            this.grid21 = new System.Windows.Forms.Label();
            this.grid02 = new System.Windows.Forms.Label();
            this.grid12 = new System.Windows.Forms.Label();
            this.grid22 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.statsGroup = new System.Windows.Forms.GroupBox();
            this.v_gameTies = new System.Windows.Forms.Label();
            this.v_p2Wins = new System.Windows.Forms.Label();
            this.v_p1Wins = new System.Windows.Forms.Label();
            this.l_gameTies = new System.Windows.Forms.Label();
            this.l_p2Wins = new System.Windows.Forms.Label();
            this.l_p1Wins = new System.Windows.Forms.Label();
            this.statusGroup = new System.Windows.Forms.GroupBox();
            this.v_gameStatus = new System.Windows.Forms.Label();
            this.btnStartGame = new System.Windows.Forms.Button();
            this.statsGroup.SuspendLayout();
            this.statusGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // grid00
            // 
            this.grid00.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid00.Location = new System.Drawing.Point(84, 60);
            this.grid00.Name = "grid00";
            this.grid00.Size = new System.Drawing.Size(124, 112);
            this.grid00.TabIndex = 0;
            this.grid00.Tag = "00";
            this.grid00.Text = "X";
            this.grid00.Click += new System.EventHandler(this.gridClick);
            // 
            // grid10
            // 
            this.grid10.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid10.Location = new System.Drawing.Point(214, 60);
            this.grid10.Name = "grid10";
            this.grid10.Size = new System.Drawing.Size(145, 112);
            this.grid10.TabIndex = 0;
            this.grid10.Tag = "10";
            this.grid10.Text = "X";
            this.grid10.Click += new System.EventHandler(this.gridClick);
            // 
            // grid20
            // 
            this.grid20.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid20.Location = new System.Drawing.Point(354, 60);
            this.grid20.Name = "grid20";
            this.grid20.Size = new System.Drawing.Size(124, 112);
            this.grid20.TabIndex = 0;
            this.grid20.Tag = "20";
            this.grid20.Text = "X";
            this.grid20.Click += new System.EventHandler(this.gridClick);
            // 
            // grid01
            // 
            this.grid01.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid01.Location = new System.Drawing.Point(83, 182);
            this.grid01.Name = "grid01";
            this.grid01.Size = new System.Drawing.Size(125, 125);
            this.grid01.TabIndex = 0;
            this.grid01.Tag = "01";
            this.grid01.Text = "X";
            this.grid01.Click += new System.EventHandler(this.gridClick);
            // 
            // grid11
            // 
            this.grid11.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid11.Location = new System.Drawing.Point(214, 182);
            this.grid11.Name = "grid11";
            this.grid11.Size = new System.Drawing.Size(145, 135);
            this.grid11.TabIndex = 0;
            this.grid11.Tag = "11";
            this.grid11.Text = "X";
            this.grid11.Click += new System.EventHandler(this.gridClick);
            // 
            // grid21
            // 
            this.grid21.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid21.Location = new System.Drawing.Point(354, 182);
            this.grid21.Name = "grid21";
            this.grid21.Size = new System.Drawing.Size(124, 135);
            this.grid21.TabIndex = 0;
            this.grid21.Tag = "21";
            this.grid21.Text = "X";
            this.grid21.Click += new System.EventHandler(this.gridClick);
            // 
            // grid02
            // 
            this.grid02.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid02.Location = new System.Drawing.Point(84, 317);
            this.grid02.Name = "grid02";
            this.grid02.Size = new System.Drawing.Size(124, 135);
            this.grid02.TabIndex = 0;
            this.grid02.Tag = "02";
            this.grid02.Text = "X";
            this.grid02.Click += new System.EventHandler(this.gridClick);
            // 
            // grid12
            // 
            this.grid12.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid12.Location = new System.Drawing.Point(214, 317);
            this.grid12.Name = "grid12";
            this.grid12.Size = new System.Drawing.Size(145, 135);
            this.grid12.TabIndex = 0;
            this.grid12.Tag = "12";
            this.grid12.Text = "X";
            this.grid12.Click += new System.EventHandler(this.gridClick);
            // 
            // grid22
            // 
            this.grid22.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid22.Location = new System.Drawing.Point(354, 317);
            this.grid22.Name = "grid22";
            this.grid22.Size = new System.Drawing.Size(124, 135);
            this.grid22.TabIndex = 0;
            this.grid22.Tag = "22";
            this.grid22.Text = "X";
            this.grid22.Click += new System.EventHandler(this.gridClick);
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(204, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(12, 392);
            this.label10.TabIndex = 1;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(351, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(12, 392);
            this.label11.TabIndex = 1;
            this.label11.Text = "label10";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(81, 172);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(397, 10);
            this.label12.TabIndex = 1;
            this.label12.Text = "label10";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(81, 307);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(397, 10);
            this.label13.TabIndex = 1;
            this.label13.Text = "label10";
            // 
            // statsGroup
            // 
            this.statsGroup.Controls.Add(this.v_gameTies);
            this.statsGroup.Controls.Add(this.v_p2Wins);
            this.statsGroup.Controls.Add(this.v_p1Wins);
            this.statsGroup.Controls.Add(this.l_gameTies);
            this.statsGroup.Controls.Add(this.l_p2Wins);
            this.statsGroup.Controls.Add(this.l_p1Wins);
            this.statsGroup.Location = new System.Drawing.Point(595, 60);
            this.statsGroup.Name = "statsGroup";
            this.statsGroup.Size = new System.Drawing.Size(200, 122);
            this.statsGroup.TabIndex = 2;
            this.statsGroup.TabStop = false;
            this.statsGroup.Text = "Statistics";
            // 
            // v_gameTies
            // 
            this.v_gameTies.AutoSize = true;
            this.v_gameTies.Location = new System.Drawing.Point(113, 78);
            this.v_gameTies.Name = "v_gameTies";
            this.v_gameTies.Size = new System.Drawing.Size(13, 13);
            this.v_gameTies.TabIndex = 5;
            this.v_gameTies.Text = "0";
            // 
            // v_p2Wins
            // 
            this.v_p2Wins.AutoSize = true;
            this.v_p2Wins.Location = new System.Drawing.Point(113, 57);
            this.v_p2Wins.Name = "v_p2Wins";
            this.v_p2Wins.Size = new System.Drawing.Size(13, 13);
            this.v_p2Wins.TabIndex = 4;
            this.v_p2Wins.Text = "0";
            // 
            // v_p1Wins
            // 
            this.v_p1Wins.AutoSize = true;
            this.v_p1Wins.Location = new System.Drawing.Point(112, 35);
            this.v_p1Wins.Name = "v_p1Wins";
            this.v_p1Wins.Size = new System.Drawing.Size(13, 13);
            this.v_p1Wins.TabIndex = 3;
            this.v_p1Wins.Text = "0";
            // 
            // l_gameTies
            // 
            this.l_gameTies.AutoSize = true;
            this.l_gameTies.Location = new System.Drawing.Point(76, 78);
            this.l_gameTies.Name = "l_gameTies";
            this.l_gameTies.Size = new System.Drawing.Size(30, 13);
            this.l_gameTies.TabIndex = 2;
            this.l_gameTies.Text = "Ties:";
            // 
            // l_p2Wins
            // 
            this.l_p2Wins.AutoSize = true;
            this.l_p2Wins.Location = new System.Drawing.Point(26, 57);
            this.l_p2Wins.Name = "l_p2Wins";
            this.l_p2Wins.Size = new System.Drawing.Size(80, 13);
            this.l_p2Wins.TabIndex = 1;
            this.l_p2Wins.Text = "Playser 2 Wins:";
            // 
            // l_p1Wins
            // 
            this.l_p1Wins.AutoSize = true;
            this.l_p1Wins.Location = new System.Drawing.Point(31, 35);
            this.l_p1Wins.Name = "l_p1Wins";
            this.l_p1Wins.Size = new System.Drawing.Size(75, 13);
            this.l_p1Wins.TabIndex = 0;
            this.l_p1Wins.Text = "Player 1 Wins:";
            // 
            // statusGroup
            // 
            this.statusGroup.Controls.Add(this.v_gameStatus);
            this.statusGroup.Location = new System.Drawing.Point(84, 505);
            this.statusGroup.Name = "statusGroup";
            this.statusGroup.Size = new System.Drawing.Size(394, 100);
            this.statusGroup.TabIndex = 3;
            this.statusGroup.TabStop = false;
            this.statusGroup.Text = "Game Status";
            // 
            // v_gameStatus
            // 
            this.v_gameStatus.AutoSize = true;
            this.v_gameStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.v_gameStatus.Location = new System.Drawing.Point(6, 34);
            this.v_gameStatus.Name = "v_gameStatus";
            this.v_gameStatus.Size = new System.Drawing.Size(192, 25);
            this.v_gameStatus.TabIndex = 0;
            this.v_gameStatus.Text = "Press Start To Begin";
            // 
            // btnStartGame
            // 
            this.btnStartGame.Location = new System.Drawing.Point(595, 188);
            this.btnStartGame.Name = "btnStartGame";
            this.btnStartGame.Size = new System.Drawing.Size(75, 23);
            this.btnStartGame.TabIndex = 4;
            this.btnStartGame.Text = "Start Game";
            this.btnStartGame.UseVisualStyleBackColor = true;
            this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 636);
            this.Controls.Add(this.btnStartGame);
            this.Controls.Add(this.statusGroup);
            this.Controls.Add(this.statsGroup);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.grid22);
            this.Controls.Add(this.grid21);
            this.Controls.Add(this.grid20);
            this.Controls.Add(this.grid12);
            this.Controls.Add(this.grid02);
            this.Controls.Add(this.grid11);
            this.Controls.Add(this.grid01);
            this.Controls.Add(this.grid10);
            this.Controls.Add(this.grid00);
            this.Name = "Form1";
            this.Text = "Form1";
            this.statsGroup.ResumeLayout(false);
            this.statsGroup.PerformLayout();
            this.statusGroup.ResumeLayout(false);
            this.statusGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label grid00;
        private System.Windows.Forms.Label grid10;
        private System.Windows.Forms.Label grid20;
        private System.Windows.Forms.Label grid01;
        private System.Windows.Forms.Label grid11;
        private System.Windows.Forms.Label grid21;
        private System.Windows.Forms.Label grid02;
        private System.Windows.Forms.Label grid12;
        private System.Windows.Forms.Label grid22;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox statsGroup;
        private System.Windows.Forms.GroupBox statusGroup;
        private System.Windows.Forms.Button btnStartGame;
        private System.Windows.Forms.Label v_gameTies;
        private System.Windows.Forms.Label v_p2Wins;
        private System.Windows.Forms.Label v_p1Wins;
        private System.Windows.Forms.Label l_gameTies;
        private System.Windows.Forms.Label l_p2Wins;
        private System.Windows.Forms.Label l_p1Wins;
        private System.Windows.Forms.Label v_gameStatus;
    }
}

