﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment5
{
    /// <summary>
    /// User Class
    /// </summary>
    public class clsUser
    {
        /// <summary>
        /// Users Name
        /// </summary>
        public string uName { get; set; }

        /// <summary>
        /// Users Age
        /// </summary>
        public int age { get; set; }
    }
}
