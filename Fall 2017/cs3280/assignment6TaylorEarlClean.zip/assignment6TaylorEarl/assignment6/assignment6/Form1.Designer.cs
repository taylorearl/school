﻿namespace assignment6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flightSelect = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.passengerSelect = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.seatSelect = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_changeSeat = new System.Windows.Forms.Button();
            this.btn_deletePassenger = new System.Windows.Forms.Button();
            this.btn_addPassenger = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.flight1_1 = new System.Windows.Forms.Label();
            this.flight1_2 = new System.Windows.Forms.Label();
            this.flight1_3 = new System.Windows.Forms.Label();
            this.flight1_4 = new System.Windows.Forms.Label();
            this.flight1_5 = new System.Windows.Forms.Label();
            this.flight1_6 = new System.Windows.Forms.Label();
            this.flight1_7 = new System.Windows.Forms.Label();
            this.flight1_8 = new System.Windows.Forms.Label();
            this.flight1_9 = new System.Windows.Forms.Label();
            this.flight1_10 = new System.Windows.Forms.Label();
            this.flight1_11 = new System.Windows.Forms.Label();
            this.flight1_12 = new System.Windows.Forms.Label();
            this.flight1_13 = new System.Windows.Forms.Label();
            this.flight1_14 = new System.Windows.Forms.Label();
            this.flight1_15 = new System.Windows.Forms.Label();
            this.flight1_16 = new System.Windows.Forms.Label();
            this.flight1_17 = new System.Windows.Forms.Label();
            this.flight1_18 = new System.Windows.Forms.Label();
            this.flight1_19 = new System.Windows.Forms.Label();
            this.flight1_20 = new System.Windows.Forms.Label();
            this.flight1_21 = new System.Windows.Forms.Label();
            this.flight1_22 = new System.Windows.Forms.Label();
            this.flight1_23 = new System.Windows.Forms.Label();
            this.flight1_24 = new System.Windows.Forms.Label();
            this.flightName = new System.Windows.Forms.Label();
            this.flight2_1 = new System.Windows.Forms.Label();
            this.flight2_2 = new System.Windows.Forms.Label();
            this.flight2_7 = new System.Windows.Forms.Label();
            this.flight2_3 = new System.Windows.Forms.Label();
            this.flight2_13 = new System.Windows.Forms.Label();
            this.flight2_8 = new System.Windows.Forms.Label();
            this.flight2_19 = new System.Windows.Forms.Label();
            this.flight2_4 = new System.Windows.Forms.Label();
            this.flight2_14 = new System.Windows.Forms.Label();
            this.flight2_9 = new System.Windows.Forms.Label();
            this.flight2_20 = new System.Windows.Forms.Label();
            this.flight2_5 = new System.Windows.Forms.Label();
            this.flight2_15 = new System.Windows.Forms.Label();
            this.flight2_10 = new System.Windows.Forms.Label();
            this.flight2_21 = new System.Windows.Forms.Label();
            this.flight2_6 = new System.Windows.Forms.Label();
            this.flight2_16 = new System.Windows.Forms.Label();
            this.flight2_11 = new System.Windows.Forms.Label();
            this.flight2_22 = new System.Windows.Forms.Label();
            this.flight2_12 = new System.Windows.Forms.Label();
            this.flight2_17 = new System.Windows.Forms.Label();
            this.flight2_18 = new System.Windows.Forms.Label();
            this.flight2_23 = new System.Windows.Forms.Label();
            this.flight2_24 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flightSelect
            // 
            this.flightSelect.FormattingEnabled = true;
            this.flightSelect.Location = new System.Drawing.Point(424, 22);
            this.flightSelect.Name = "flightSelect";
            this.flightSelect.Size = new System.Drawing.Size(121, 21);
            this.flightSelect.TabIndex = 0;
            this.flightSelect.SelectedIndexChanged += new System.EventHandler(this.flightSelect_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(321, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose Flight:";
            // 
            // passengerSelect
            // 
            this.passengerSelect.FormattingEnabled = true;
            this.passengerSelect.Location = new System.Drawing.Point(424, 49);
            this.passengerSelect.Name = "passengerSelect";
            this.passengerSelect.Size = new System.Drawing.Size(121, 21);
            this.passengerSelect.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Passenger:";
            // 
            // seatSelect
            // 
            this.seatSelect.FormattingEnabled = true;
            this.seatSelect.Location = new System.Drawing.Point(424, 76);
            this.seatSelect.Name = "seatSelect";
            this.seatSelect.Size = new System.Drawing.Size(121, 21);
            this.seatSelect.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(303, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Passenger\'s Seat:";
            // 
            // btn_changeSeat
            // 
            this.btn_changeSeat.Location = new System.Drawing.Point(424, 119);
            this.btn_changeSeat.Name = "btn_changeSeat";
            this.btn_changeSeat.Size = new System.Drawing.Size(120, 23);
            this.btn_changeSeat.TabIndex = 2;
            this.btn_changeSeat.Text = "Change Seat";
            this.btn_changeSeat.UseVisualStyleBackColor = true;
            // 
            // btn_deletePassenger
            // 
            this.btn_deletePassenger.Location = new System.Drawing.Point(424, 148);
            this.btn_deletePassenger.Name = "btn_deletePassenger";
            this.btn_deletePassenger.Size = new System.Drawing.Size(120, 23);
            this.btn_deletePassenger.TabIndex = 2;
            this.btn_deletePassenger.Text = "Delete Passenger";
            this.btn_deletePassenger.UseVisualStyleBackColor = true;
            // 
            // btn_addPassenger
            // 
            this.btn_addPassenger.Location = new System.Drawing.Point(298, 148);
            this.btn_addPassenger.Name = "btn_addPassenger";
            this.btn_addPassenger.Size = new System.Drawing.Size(120, 23);
            this.btn_addPassenger.TabIndex = 2;
            this.btn_addPassenger.Text = "Add Passenger";
            this.btn_addPassenger.UseVisualStyleBackColor = true;
            this.btn_addPassenger.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(298, 190);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 119);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color Key";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(94, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Selected Passengers Seat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(94, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Seat is empty";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(94, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Seat is taken";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Lime;
            this.label6.ForeColor = System.Drawing.Color.Lime;
            this.label6.Location = new System.Drawing.Point(23, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 26);
            this.label6.TabIndex = 0;
            this.label6.Text = "label4";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.RoyalBlue;
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(23, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 26);
            this.label4.TabIndex = 0;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Red;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(23, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "label4";
            // 
            // flight1_1
            // 
            this.flight1_1.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_1.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_1.Location = new System.Drawing.Point(26, 52);
            this.flight1_1.Name = "flight1_1";
            this.flight1_1.Size = new System.Drawing.Size(28, 26);
            this.flight1_1.TabIndex = 0;
            this.flight1_1.Text = "1";
            // 
            // flight1_2
            // 
            this.flight1_2.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_2.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_2.Location = new System.Drawing.Point(60, 52);
            this.flight1_2.Name = "flight1_2";
            this.flight1_2.Size = new System.Drawing.Size(28, 26);
            this.flight1_2.TabIndex = 0;
            this.flight1_2.Text = "2";
            this.flight1_2.Click += new System.EventHandler(this.label11_Click);
            // 
            // flight1_3
            // 
            this.flight1_3.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_3.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_3.Location = new System.Drawing.Point(94, 52);
            this.flight1_3.Name = "flight1_3";
            this.flight1_3.Size = new System.Drawing.Size(28, 26);
            this.flight1_3.TabIndex = 0;
            this.flight1_3.Text = "3";
            // 
            // flight1_4
            // 
            this.flight1_4.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_4.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_4.Location = new System.Drawing.Point(157, 52);
            this.flight1_4.Name = "flight1_4";
            this.flight1_4.Size = new System.Drawing.Size(28, 26);
            this.flight1_4.TabIndex = 0;
            this.flight1_4.Text = "4";
            this.flight1_4.Click += new System.EventHandler(this.label13_Click);
            // 
            // flight1_5
            // 
            this.flight1_5.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_5.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_5.Location = new System.Drawing.Point(191, 52);
            this.flight1_5.Name = "flight1_5";
            this.flight1_5.Size = new System.Drawing.Size(28, 26);
            this.flight1_5.TabIndex = 0;
            this.flight1_5.Text = "5";
            // 
            // flight1_6
            // 
            this.flight1_6.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_6.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_6.Location = new System.Drawing.Point(225, 52);
            this.flight1_6.Name = "flight1_6";
            this.flight1_6.Size = new System.Drawing.Size(28, 26);
            this.flight1_6.TabIndex = 0;
            this.flight1_6.Text = "6";
            this.flight1_6.Click += new System.EventHandler(this.label15_Click);
            // 
            // flight1_7
            // 
            this.flight1_7.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_7.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_7.Location = new System.Drawing.Point(26, 98);
            this.flight1_7.Name = "flight1_7";
            this.flight1_7.Size = new System.Drawing.Size(28, 26);
            this.flight1_7.TabIndex = 0;
            this.flight1_7.Text = "7";
            // 
            // flight1_8
            // 
            this.flight1_8.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_8.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_8.Location = new System.Drawing.Point(60, 98);
            this.flight1_8.Name = "flight1_8";
            this.flight1_8.Size = new System.Drawing.Size(28, 26);
            this.flight1_8.TabIndex = 0;
            this.flight1_8.Text = "8";
            // 
            // flight1_9
            // 
            this.flight1_9.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_9.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_9.Location = new System.Drawing.Point(94, 98);
            this.flight1_9.Name = "flight1_9";
            this.flight1_9.Size = new System.Drawing.Size(28, 26);
            this.flight1_9.TabIndex = 0;
            this.flight1_9.Text = "9";
            // 
            // flight1_10
            // 
            this.flight1_10.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_10.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_10.Location = new System.Drawing.Point(157, 98);
            this.flight1_10.Name = "flight1_10";
            this.flight1_10.Size = new System.Drawing.Size(28, 26);
            this.flight1_10.TabIndex = 0;
            this.flight1_10.Text = "10";
            // 
            // flight1_11
            // 
            this.flight1_11.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_11.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_11.Location = new System.Drawing.Point(191, 98);
            this.flight1_11.Name = "flight1_11";
            this.flight1_11.Size = new System.Drawing.Size(28, 26);
            this.flight1_11.TabIndex = 0;
            this.flight1_11.Text = "11";
            // 
            // flight1_12
            // 
            this.flight1_12.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_12.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_12.Location = new System.Drawing.Point(225, 98);
            this.flight1_12.Name = "flight1_12";
            this.flight1_12.Size = new System.Drawing.Size(28, 26);
            this.flight1_12.TabIndex = 0;
            this.flight1_12.Text = "12";
            // 
            // flight1_13
            // 
            this.flight1_13.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_13.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_13.Location = new System.Drawing.Point(26, 133);
            this.flight1_13.Name = "flight1_13";
            this.flight1_13.Size = new System.Drawing.Size(28, 26);
            this.flight1_13.TabIndex = 0;
            this.flight1_13.Text = "13";
            // 
            // flight1_14
            // 
            this.flight1_14.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_14.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_14.Location = new System.Drawing.Point(60, 133);
            this.flight1_14.Name = "flight1_14";
            this.flight1_14.Size = new System.Drawing.Size(28, 26);
            this.flight1_14.TabIndex = 0;
            this.flight1_14.Text = "14";
            // 
            // flight1_15
            // 
            this.flight1_15.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_15.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_15.Location = new System.Drawing.Point(94, 133);
            this.flight1_15.Name = "flight1_15";
            this.flight1_15.Size = new System.Drawing.Size(28, 26);
            this.flight1_15.TabIndex = 0;
            this.flight1_15.Text = "15";
            // 
            // flight1_16
            // 
            this.flight1_16.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_16.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_16.Location = new System.Drawing.Point(157, 133);
            this.flight1_16.Name = "flight1_16";
            this.flight1_16.Size = new System.Drawing.Size(28, 26);
            this.flight1_16.TabIndex = 0;
            this.flight1_16.Text = "16";
            // 
            // flight1_17
            // 
            this.flight1_17.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_17.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_17.Location = new System.Drawing.Point(191, 133);
            this.flight1_17.Name = "flight1_17";
            this.flight1_17.Size = new System.Drawing.Size(28, 26);
            this.flight1_17.TabIndex = 0;
            this.flight1_17.Text = "17";
            // 
            // flight1_18
            // 
            this.flight1_18.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_18.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_18.Location = new System.Drawing.Point(225, 133);
            this.flight1_18.Name = "flight1_18";
            this.flight1_18.Size = new System.Drawing.Size(28, 26);
            this.flight1_18.TabIndex = 0;
            this.flight1_18.Text = "18";
            // 
            // flight1_19
            // 
            this.flight1_19.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_19.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_19.Location = new System.Drawing.Point(26, 168);
            this.flight1_19.Name = "flight1_19";
            this.flight1_19.Size = new System.Drawing.Size(28, 26);
            this.flight1_19.TabIndex = 0;
            this.flight1_19.Text = "19";
            // 
            // flight1_20
            // 
            this.flight1_20.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_20.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_20.Location = new System.Drawing.Point(60, 168);
            this.flight1_20.Name = "flight1_20";
            this.flight1_20.Size = new System.Drawing.Size(28, 26);
            this.flight1_20.TabIndex = 0;
            this.flight1_20.Text = "20";
            // 
            // flight1_21
            // 
            this.flight1_21.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_21.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_21.Location = new System.Drawing.Point(94, 168);
            this.flight1_21.Name = "flight1_21";
            this.flight1_21.Size = new System.Drawing.Size(28, 26);
            this.flight1_21.TabIndex = 0;
            this.flight1_21.Text = "21";
            // 
            // flight1_22
            // 
            this.flight1_22.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_22.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_22.Location = new System.Drawing.Point(157, 168);
            this.flight1_22.Name = "flight1_22";
            this.flight1_22.Size = new System.Drawing.Size(28, 26);
            this.flight1_22.TabIndex = 0;
            this.flight1_22.Text = "22";
            // 
            // flight1_23
            // 
            this.flight1_23.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_23.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_23.Location = new System.Drawing.Point(191, 168);
            this.flight1_23.Name = "flight1_23";
            this.flight1_23.Size = new System.Drawing.Size(28, 26);
            this.flight1_23.TabIndex = 0;
            this.flight1_23.Text = "23";
            // 
            // flight1_24
            // 
            this.flight1_24.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight1_24.ForeColor = System.Drawing.Color.Yellow;
            this.flight1_24.Location = new System.Drawing.Point(225, 168);
            this.flight1_24.Name = "flight1_24";
            this.flight1_24.Size = new System.Drawing.Size(28, 26);
            this.flight1_24.TabIndex = 0;
            this.flight1_24.Text = "24";
            // 
            // flightName
            // 
            this.flightName.AutoSize = true;
            this.flightName.Location = new System.Drawing.Point(116, 22);
            this.flightName.Name = "flightName";
            this.flightName.Size = new System.Drawing.Size(0, 13);
            this.flightName.TabIndex = 4;
            // 
            // flight2_1
            // 
            this.flight2_1.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_1.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_1.Location = new System.Drawing.Point(60, 52);
            this.flight2_1.Name = "flight2_1";
            this.flight2_1.Size = new System.Drawing.Size(28, 26);
            this.flight2_1.TabIndex = 0;
            this.flight2_1.Text = "1";
            // 
            // flight2_2
            // 
            this.flight2_2.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_2.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_2.Location = new System.Drawing.Point(94, 52);
            this.flight2_2.Name = "flight2_2";
            this.flight2_2.Size = new System.Drawing.Size(28, 26);
            this.flight2_2.TabIndex = 0;
            this.flight2_2.Text = "2";
            this.flight2_2.Click += new System.EventHandler(this.label11_Click);
            // 
            // flight2_7
            // 
            this.flight2_7.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_7.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_7.Location = new System.Drawing.Point(157, 88);
            this.flight2_7.Name = "flight2_7";
            this.flight2_7.Size = new System.Drawing.Size(28, 26);
            this.flight2_7.TabIndex = 0;
            this.flight2_7.Text = "7";
            // 
            // flight2_3
            // 
            this.flight2_3.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_3.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_3.Location = new System.Drawing.Point(157, 52);
            this.flight2_3.Name = "flight2_3";
            this.flight2_3.Size = new System.Drawing.Size(28, 26);
            this.flight2_3.TabIndex = 0;
            this.flight2_3.Text = "3";
            // 
            // flight2_13
            // 
            this.flight2_13.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_13.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_13.Location = new System.Drawing.Point(60, 159);
            this.flight2_13.Name = "flight2_13";
            this.flight2_13.Size = new System.Drawing.Size(28, 26);
            this.flight2_13.TabIndex = 0;
            this.flight2_13.Text = "13";
            // 
            // flight2_8
            // 
            this.flight2_8.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_8.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_8.Location = new System.Drawing.Point(191, 88);
            this.flight2_8.Name = "flight2_8";
            this.flight2_8.Size = new System.Drawing.Size(28, 26);
            this.flight2_8.TabIndex = 0;
            this.flight2_8.Text = "8";
            // 
            // flight2_19
            // 
            this.flight2_19.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_19.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_19.Location = new System.Drawing.Point(157, 194);
            this.flight2_19.Name = "flight2_19";
            this.flight2_19.Size = new System.Drawing.Size(28, 26);
            this.flight2_19.TabIndex = 0;
            this.flight2_19.Text = "19";
            // 
            // flight2_4
            // 
            this.flight2_4.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_4.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_4.Location = new System.Drawing.Point(191, 52);
            this.flight2_4.Name = "flight2_4";
            this.flight2_4.Size = new System.Drawing.Size(28, 26);
            this.flight2_4.TabIndex = 0;
            this.flight2_4.Text = "4";
            this.flight2_4.Click += new System.EventHandler(this.label13_Click);
            // 
            // flight2_14
            // 
            this.flight2_14.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_14.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_14.Location = new System.Drawing.Point(94, 159);
            this.flight2_14.Name = "flight2_14";
            this.flight2_14.Size = new System.Drawing.Size(28, 26);
            this.flight2_14.TabIndex = 0;
            this.flight2_14.Text = "14";
            // 
            // flight2_9
            // 
            this.flight2_9.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_9.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_9.Location = new System.Drawing.Point(60, 123);
            this.flight2_9.Name = "flight2_9";
            this.flight2_9.Size = new System.Drawing.Size(28, 26);
            this.flight2_9.TabIndex = 0;
            this.flight2_9.Text = "9";
            // 
            // flight2_20
            // 
            this.flight2_20.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_20.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_20.Location = new System.Drawing.Point(191, 194);
            this.flight2_20.Name = "flight2_20";
            this.flight2_20.Size = new System.Drawing.Size(28, 26);
            this.flight2_20.TabIndex = 0;
            this.flight2_20.Text = "20";
            // 
            // flight2_5
            // 
            this.flight2_5.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_5.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_5.Location = new System.Drawing.Point(60, 88);
            this.flight2_5.Name = "flight2_5";
            this.flight2_5.Size = new System.Drawing.Size(28, 26);
            this.flight2_5.TabIndex = 0;
            this.flight2_5.Text = "5";
            // 
            // flight2_15
            // 
            this.flight2_15.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_15.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_15.Location = new System.Drawing.Point(157, 159);
            this.flight2_15.Name = "flight2_15";
            this.flight2_15.Size = new System.Drawing.Size(28, 26);
            this.flight2_15.TabIndex = 0;
            this.flight2_15.Text = "15";
            // 
            // flight2_10
            // 
            this.flight2_10.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_10.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_10.Location = new System.Drawing.Point(94, 123);
            this.flight2_10.Name = "flight2_10";
            this.flight2_10.Size = new System.Drawing.Size(28, 26);
            this.flight2_10.TabIndex = 0;
            this.flight2_10.Text = "10";
            // 
            // flight2_21
            // 
            this.flight2_21.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_21.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_21.Location = new System.Drawing.Point(60, 232);
            this.flight2_21.Name = "flight2_21";
            this.flight2_21.Size = new System.Drawing.Size(28, 26);
            this.flight2_21.TabIndex = 0;
            this.flight2_21.Text = "21";
            // 
            // flight2_6
            // 
            this.flight2_6.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_6.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_6.Location = new System.Drawing.Point(94, 88);
            this.flight2_6.Name = "flight2_6";
            this.flight2_6.Size = new System.Drawing.Size(28, 26);
            this.flight2_6.TabIndex = 0;
            this.flight2_6.Text = "6";
            // 
            // flight2_16
            // 
            this.flight2_16.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_16.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_16.Location = new System.Drawing.Point(191, 159);
            this.flight2_16.Name = "flight2_16";
            this.flight2_16.Size = new System.Drawing.Size(28, 26);
            this.flight2_16.TabIndex = 0;
            this.flight2_16.Text = "16";
            // 
            // flight2_11
            // 
            this.flight2_11.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_11.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_11.Location = new System.Drawing.Point(157, 123);
            this.flight2_11.Name = "flight2_11";
            this.flight2_11.Size = new System.Drawing.Size(28, 26);
            this.flight2_11.TabIndex = 0;
            this.flight2_11.Text = "11";
            // 
            // flight2_22
            // 
            this.flight2_22.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_22.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_22.Location = new System.Drawing.Point(94, 232);
            this.flight2_22.Name = "flight2_22";
            this.flight2_22.Size = new System.Drawing.Size(28, 26);
            this.flight2_22.TabIndex = 0;
            this.flight2_22.Text = "22";
            // 
            // flight2_12
            // 
            this.flight2_12.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_12.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_12.Location = new System.Drawing.Point(191, 123);
            this.flight2_12.Name = "flight2_12";
            this.flight2_12.Size = new System.Drawing.Size(28, 26);
            this.flight2_12.TabIndex = 0;
            this.flight2_12.Text = "12";
            // 
            // flight2_17
            // 
            this.flight2_17.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_17.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_17.Location = new System.Drawing.Point(60, 194);
            this.flight2_17.Name = "flight2_17";
            this.flight2_17.Size = new System.Drawing.Size(28, 26);
            this.flight2_17.TabIndex = 0;
            this.flight2_17.Text = "17";
            // 
            // flight2_18
            // 
            this.flight2_18.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_18.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_18.Location = new System.Drawing.Point(94, 194);
            this.flight2_18.Name = "flight2_18";
            this.flight2_18.Size = new System.Drawing.Size(28, 26);
            this.flight2_18.TabIndex = 0;
            this.flight2_18.Text = "18";
            // 
            // flight2_23
            // 
            this.flight2_23.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_23.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_23.Location = new System.Drawing.Point(157, 232);
            this.flight2_23.Name = "flight2_23";
            this.flight2_23.Size = new System.Drawing.Size(28, 26);
            this.flight2_23.TabIndex = 0;
            this.flight2_23.Text = "23";
            // 
            // flight2_24
            // 
            this.flight2_24.BackColor = System.Drawing.Color.RoyalBlue;
            this.flight2_24.ForeColor = System.Drawing.Color.Yellow;
            this.flight2_24.Location = new System.Drawing.Point(191, 232);
            this.flight2_24.Name = "flight2_24";
            this.flight2_24.Size = new System.Drawing.Size(28, 26);
            this.flight2_24.TabIndex = 0;
            this.flight2_24.Text = "24";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 333);
            this.Controls.Add(this.flightName);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_addPassenger);
            this.Controls.Add(this.btn_deletePassenger);
            this.Controls.Add(this.btn_changeSeat);
            this.Controls.Add(this.flight2_24);
            this.Controls.Add(this.flight2_23);
            this.Controls.Add(this.flight1_24);
            this.Controls.Add(this.flight2_18);
            this.Controls.Add(this.flight1_23);
            this.Controls.Add(this.flight2_17);
            this.Controls.Add(this.flight1_18);
            this.Controls.Add(this.flight2_12);
            this.Controls.Add(this.flight1_17);
            this.Controls.Add(this.flight2_22);
            this.Controls.Add(this.flight1_12);
            this.Controls.Add(this.flight2_11);
            this.Controls.Add(this.flight1_22);
            this.Controls.Add(this.flight2_16);
            this.Controls.Add(this.flight1_11);
            this.Controls.Add(this.flight2_6);
            this.Controls.Add(this.flight1_16);
            this.Controls.Add(this.flight2_21);
            this.Controls.Add(this.flight1_6);
            this.Controls.Add(this.flight2_10);
            this.Controls.Add(this.flight1_21);
            this.Controls.Add(this.flight2_15);
            this.Controls.Add(this.flight1_10);
            this.Controls.Add(this.flight2_5);
            this.Controls.Add(this.flight1_15);
            this.Controls.Add(this.flight2_20);
            this.Controls.Add(this.flight1_5);
            this.Controls.Add(this.flight2_9);
            this.Controls.Add(this.flight1_20);
            this.Controls.Add(this.flight2_14);
            this.Controls.Add(this.flight1_9);
            this.Controls.Add(this.flight2_4);
            this.Controls.Add(this.flight1_14);
            this.Controls.Add(this.flight2_19);
            this.Controls.Add(this.flight1_4);
            this.Controls.Add(this.flight2_8);
            this.Controls.Add(this.flight1_19);
            this.Controls.Add(this.flight2_13);
            this.Controls.Add(this.flight1_8);
            this.Controls.Add(this.flight2_3);
            this.Controls.Add(this.flight1_13);
            this.Controls.Add(this.flight2_7);
            this.Controls.Add(this.flight1_3);
            this.Controls.Add(this.flight2_2);
            this.Controls.Add(this.flight1_7);
            this.Controls.Add(this.flight2_1);
            this.Controls.Add(this.flight1_2);
            this.Controls.Add(this.flight1_1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.seatSelect);
            this.Controls.Add(this.passengerSelect);
            this.Controls.Add(this.flightSelect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox flightSelect;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox passengerSelect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox seatSelect;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_changeSeat;
        private System.Windows.Forms.Button btn_deletePassenger;
        private System.Windows.Forms.Button btn_addPassenger;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label flight1_1;
        private System.Windows.Forms.Label flight1_2;
        private System.Windows.Forms.Label flight1_3;
        private System.Windows.Forms.Label flight1_4;
        private System.Windows.Forms.Label flight1_5;
        private System.Windows.Forms.Label flight1_6;
        private System.Windows.Forms.Label flight1_7;
        private System.Windows.Forms.Label flight1_8;
        private System.Windows.Forms.Label flight1_9;
        private System.Windows.Forms.Label flight1_10;
        private System.Windows.Forms.Label flight1_11;
        private System.Windows.Forms.Label flight1_12;
        private System.Windows.Forms.Label flight1_13;
        private System.Windows.Forms.Label flight1_14;
        private System.Windows.Forms.Label flight1_15;
        private System.Windows.Forms.Label flight1_16;
        private System.Windows.Forms.Label flight1_17;
        private System.Windows.Forms.Label flight1_18;
        private System.Windows.Forms.Label flight1_19;
        private System.Windows.Forms.Label flight1_20;
        private System.Windows.Forms.Label flight1_21;
        private System.Windows.Forms.Label flight1_22;
        private System.Windows.Forms.Label flight1_23;
        private System.Windows.Forms.Label flight1_24;
        private System.Windows.Forms.Label flightName;
        private System.Windows.Forms.Label flight2_1;
        private System.Windows.Forms.Label flight2_2;
        private System.Windows.Forms.Label flight2_7;
        private System.Windows.Forms.Label flight2_3;
        private System.Windows.Forms.Label flight2_13;
        private System.Windows.Forms.Label flight2_8;
        private System.Windows.Forms.Label flight2_19;
        private System.Windows.Forms.Label flight2_4;
        private System.Windows.Forms.Label flight2_14;
        private System.Windows.Forms.Label flight2_9;
        private System.Windows.Forms.Label flight2_20;
        private System.Windows.Forms.Label flight2_5;
        private System.Windows.Forms.Label flight2_15;
        private System.Windows.Forms.Label flight2_10;
        private System.Windows.Forms.Label flight2_21;
        private System.Windows.Forms.Label flight2_6;
        private System.Windows.Forms.Label flight2_16;
        private System.Windows.Forms.Label flight2_11;
        private System.Windows.Forms.Label flight2_22;
        private System.Windows.Forms.Label flight2_12;
        private System.Windows.Forms.Label flight2_17;
        private System.Windows.Forms.Label flight2_18;
        private System.Windows.Forms.Label flight2_23;
        private System.Windows.Forms.Label flight2_24;
    }
}

